/* Simple example for Teensy USB Development Board
 * http://www.pjrc.com/teensy/
 * Copyright (c) 2008 PJRC.COM, LLC
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <util/delay.h>
#include "usb_serial.h"

#define LED_CONFIG  (DDRD |= (1<<6))
#define LED_ON    (PORTD |= (1<<6))
#define LED_OFF    (PORTD &= ~(1<<6))
#define CPU_PRESCALE(n) (CLKPR = 0x80, CLKPR = (n))

#define SS_HIGH (PORTB |= 0x01);
#define SS_LOW (PORTB &= ~(0x01));

#ifndef cbi
#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
#endif
#ifndef sbi
#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
#endif

// table of 256 sine values / one sine period / stored in flash memory
PROGMEM  prog_uchar sine256[]  = {
  127,130,133,136,139,143,146,149,152,155,158,161,164,167,170,173,176,178,181,184,187,190,192,195,198,200,203,205,208,210,212,215,217,219,221,223,225,227,229,231,233,234,236,238,239,240,
  242,243,244,245,247,248,249,249,250,251,252,252,253,253,253,254,254,254,254,254,254,254,253,253,253,252,252,251,250,249,249,248,247,245,244,243,242,240,239,238,236,234,233,231,229,227,225,223,
  221,219,217,215,212,210,208,205,203,200,198,195,192,190,187,184,181,178,176,173,170,167,164,161,158,155,152,149,146,143,139,136,133,130,127,124,121,118,115,111,108,105,102,99,96,93,90,87,84,81,78,
  76,73,70,67,64,62,59,56,54,51,49,46,44,42,39,37,35,33,31,29,27,25,23,21,20,18,16,15,14,12,11,10,9,7,6,5,5,4,3,2,2,1,1,1,0,0,0,0,0,0,0,1,1,1,2,2,3,4,5,5,6,7,9,10,11,12,14,15,16,18,20,21,23,25,27,29,31,
  33,35,37,39,42,44,46,49,51,54,56,59,62,64,67,70,73,76,78,81,84,87,90,93,96,99,102,105,108,111,115,118,121,124};

uint8_t icnt;      // var inside interrupt
uint32_t phaccu;   // pahse accumulator
uint32_t tword_m;  // dds tuning word m
uint8_t amp, cpuAmp, enable;
double dfreq;
uint16_t refclk = 16000000/1600;


void send_str(const char *s);
uint8_t recv_str(char *buf, uint8_t size);


ISR(TIMER3_COMPA_vect) {
  phaccu = phaccu + tword_m; // soft DDS, phase accu with 32 bits
  icnt = phaccu >> 24;       // use upper 8 bits for phase accu as frequency information
  // read value from ROM sine table and send to DAC
  int16_t lookup = ((int16_t)pgm_read_byte_near(sine256 + icnt) - 127) * amp;
  SS_LOW;
  SPDR = 0x00;
  while (!(SPSR & (1<<SPIF))) ;
  SPDR = ((uint8_t*)&lookup)[1];
  while (!(SPSR & (1<<SPIF))) ;
  SPDR = ((uint8_t*)&lookup)[0];
  while (!(SPSR & (1<<SPIF))) ;
  SS_HIGH;

  if (icnt < 3) { // start of new cycle
    if (ADCSRA & (1<<ADIF)) {
      if ((PIND & 0x40) == 0) { //manual control
        amp = ADCH;
        PORTB |= 0x20; //turn the LED on
      } else if (((PIND & 0x80) == 0) && enable) { //computer control
        amp = cpuAmp;
        PORTB |= 0x20; //turn the LED on
      } else {
        amp = 0;
        PORTB &= ~(0x20);
      }
      ADCSRA |= 0x60;
    }
  }
}

uint8_t spiTransfer(uint8_t value)
{
  SPDR = value;
  while (!(SPSR & (1<<SPIF))) ;
  return SPDR;
}

void spiMode(uint8_t config)
{
  uint8_t tmp;

  // enable SPI master with configuration byte specified
  SPCR = 0;
  SPCR = (config & 0x7F) | (1<<SPE) | (1<<MSTR);
  SPSR = 1<<SPI2X;
  tmp = SPSR;
  tmp = SPDR;
}

void parse(char *line, char **argv, uint8_t maxArgs) {
  uint8_t argCount = 0;
  while (*line != '\0') {       /* if not the end of line ....... */

    while (*line == ',' || *line == ' ' || *line == '\t' || *line == '\n')
      *line++ = '\0';     /* replace commas and white spaces with 0    */
    *argv++ = line;          /* save the argument position     */
    argCount++;
    if (argCount == maxArgs-1)
      break;
    while (*line != '\0' && *line != ',' && *line != ' ' && 
      *line != '\t' && *line != '\n') 
      line++;             /* skip the argument until ...    */
  }
  *argv = line;                 /* mark the end of argument list  */
}

// print a string
void printString(char *line) {
  while (*line)
    usb_serial_putchar(*line++);
}

// Send a string to the USB serial port.  The string must be in
// flash memory, using PSTR
//
void send_str(const char *s)
{
  char c;
  while (1) {
    c = pgm_read_byte(s++);
    if (!c) break;
    usb_serial_putchar(c);
  }
}

// Receive a string from the USB serial port.  The string is stored
// in the buffer and this function will not exceed the buffer size.
// A carriage return or newline completes the string, and is not
// stored into the buffer.
// The return value is the number of characters received, or 255 if
// the virtual serial connection was closed while waiting.
//
uint8_t recv_str(char *buf, uint8_t size)
{
  int16_t r;
  uint8_t count=0;

  while (count < size) {
    r = usb_serial_getchar();
    if (r != -1) {
      if (r == '\r' || r == '\n') return count;
      if (r >= ' ' && r <= '~') {
        *buf++ = r;
//        usb_serial_putchar(r);
        count++;
      }
    } else {
      if (!usb_configured() ||
        !(usb_serial_get_control() & USB_SERIAL_DTR)) {
        // user no longer connected
        return 255;
      }
      // just a normal timeout, keep waiting
    }
  }
  return count;
}


// Basic command interpreter
int main(void)
{
  char buf[128];
  uint8_t n;
  char *argv[8]; // input line arguments (as character strings)

  // set for 16 MHz clock
  CPU_PRESCALE(0);

  // SPI init
  DDRB |= 0x27; // set SS, SCLK, MOSI and LED as outputs
  PORTB |= 0x01; // set SS high
    
  // use SPI clock mode 2
  spiMode(1<<CPOL); // SPI mode 2

  // DAC (AD5754) setup
  /* DAC power control register (all ch + ref powered up)*/
  SS_LOW;
  spiTransfer(0x10);
  spiTransfer(0x00);
  spiTransfer(0x1f);
  SS_HIGH;
  
  /* DAC control register (SDO turned off) */
  SS_LOW;
  spiTransfer(0x19);
  spiTransfer(0x00);
  spiTransfer(0x0d);
  SS_HIGH;
  
  /* DAC output range register (all ch +/-5V range)*/
  SS_LOW;
  spiTransfer(0x0c); // all four DACs
  spiTransfer(0x00);
  spiTransfer(0x03); // 3 = +/-5V range
  SS_HIGH;
  
  // set timer 3 prescale factor to 1
  sbi(TCCR3B, CS30);
  // put timer 3 in CTC mode, TOP = 1600, i.e. 10 kHz
  sbi(TCCR3B, WGM32);
  OCR3A = 1599;

  sbi(TIMSK3, OCIE3A); // enable timer 3 compare interrupt

  amp = 0;
  cpuAmp = 0;
  enable = 0;
  dfreq = 86.0;
  tword_m = (0x100000000/refclk)*dfreq;  // calulate DDS new tuning word
  phaccu = 0;

  ADMUX = 0x60; // Vcc is ref, left-justify the adc result
  ADCSRA = 0xc7; // adc enable, prescale = 128
  
  // initialize the USB, and then wait for the host
  // to set configuration.  If the Teensy is powered
  // without a PC connected to the USB port, this 
  // will wait forever.
  usb_init();
  while (!usb_configured()) /* wait */ ;
  _delay_ms(1000);

  while (1) {
    // wait for the user to run their terminal emulator program
    // which sets DTR to indicate it is ready to receive.
    while (!(usb_serial_get_control() & USB_SERIAL_DTR)) /* wait */ ;

    // discard anything that was received prior.  Sometimes the
    // operating system or other software will send a modem
    // "AT command", which can still be buffered.
    usb_serial_flush_input();

    // print a nice welcome message
//    send_str(PSTR("\r\n*** Vibratome control ***\r\n"
//      "Commands:\r\n"
//      "amp <value>: set the amplitude to <value>, value in the range 0 to 255\r\n"
//      "amp: print the current amplitude value\r\n\n"));

    // and then listen for commands and process them
    while (1) {
//      send_str(PSTR("> "));
      n = recv_str(buf, sizeof(buf));
      if (n == 255) break;
//      send_str(PSTR("\r\n"));
      buf[n] = '\0';
      parse((char*)buf, argv, sizeof(argv));
      if (strcmp(argv[0], "amp") == 0) {
        if (strlen(argv[1]) > 0) {
          cpuAmp = atoi(argv[1]);
        } else {
          sprintf(buf, "Amplitude = %u\r\n", amp);
          printString(buf);
        }
      } else if (strcmp(argv[0], "stop") == 0) {
        enable = 0;
      } else if ((strcmp(argv[0], "run") == 0) ||
                 (strcmp(argv[0], "start") == 0)) {
        enable = 1;
      }
    }
  }
}




